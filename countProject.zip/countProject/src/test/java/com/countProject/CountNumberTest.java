package com.countProject;

import org.junit.Test;

import junit.framework.TestCase;
public class CountNumberTest extends TestCase {
	@Test
	public void test(){
		CountNumber countNum=new CountNumber();
		String result=countNum.getResult(3);
		assertEquals("Fizz", result);
	}

}
