package com.countProject;

import org.junit.Test;

import junit.framework.TestCase;
public class CountNumberNewTest extends TestCase {
	@Test
	public void test(){
		CountNumberNew countNumNew=new CountNumberNew();
		String result=countNumNew.getResult(53);
		assertEquals("FizzBuzz", result);
	}

}
