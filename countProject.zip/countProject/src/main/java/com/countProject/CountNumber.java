package com.countProject;

public class CountNumber {
	/**
	 * @param num
	 * @return
	 * 判断是否为3,5的倍数，并返回相应结果
	 * a为3的倍数返回结果，b为5倍数返回结果，c为3,5倍数返回结果，d为其他结果
	 */
	public static String getResult(int num){
		String result=String.valueOf(num);
		if(num%3==0){
			if(num%5==0)
				result="FizzBuzz";
			else
				result="Fizz";
		}else {
			if(num%5==0)
				result="Buzz";		
		}
		return result;
	}
	
 public static void main(String arg[]){
	 String res;
	 for(int i=1;i<=100;i++){	
		res=getResult(i);
		System.out.println(res);
		
	 }
	 
	 
 }
}
