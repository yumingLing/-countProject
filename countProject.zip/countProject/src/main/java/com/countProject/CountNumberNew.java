package com.countProject;

public class CountNumberNew {
	/**
	 * @param num
	 * @return
	 * 判断是否为3,5的倍数或者包含3，并返回相应结果
	 */
	public static String getResult(int num){
		String result=String.valueOf(num);
		//能被3整除的
		if(num%3==0){
			//能被3，5同时整除的
			if(num%5==0){
				return "FizzBuzz";
			}else{
				return "Fizz";
			}
				
		}else {
			if(num%5==0){
				return "Buzz";	
			}
			//判断是否包含3或者5
			else{
				String sNum=String.valueOf(num);
				if(sNum.contains("3")){
					//判断是否同时包含5,这样两种情况都包含
					if(sNum.contains("5")){
						return "FizzBuzz";
					}else{
						//值包含3
						return "Fizz";
					}
				}else{
					//判断是否包含5
					if(sNum.contains("5")){
						return "Buzz";	
					}else{
						//啥都没，返回原来的值
						return result;
					}
				}
			}
			
		}
	}
	
	
 public static void main(String arg[]){
	 String res;
	 for(int i=1;i<=100;i++){	
		res=getResult(i);
		System.out.println(res);
		
	 }
	 
 }
}
